# routes/citas.py

from flask import Blueprint, request, jsonify
from db import get_db_connection

citas_bp = Blueprint("citas", __name__)

@citas_bp.route("/citas", methods=["GET"])
def obtener_citas():
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM citas")
    rows = cursor.fetchall()
    conn.close()

    # Formatear para Event-Calendar
    eventos = []
    for row in rows:
        evento = {
            "id": row["id"],
            "title": f"{row['categoria'].capitalize()}: {row['nombre']}",
            "start": row["inicio"].isoformat(),
            "end": row["fin"].isoformat(),
            "extendedProps": {
                "categoria": row["categoria"],
                "motivo": row["motivo"],
                "nombre": row["nombre"],
                "seccion": row["seccion"],
                "ocupacion": row["ocupacion"]
            }
        }
        eventos.append(evento)

    return jsonify(eventos)

@citas_bp.route("/citas", methods=["POST"])
def crear_cita():
    data = request.json

    conn = get_db_connection()
    cursor = conn.cursor()

    sql = """
        INSERT INTO citas
        (categoria, motivo, nombre, seccion, ocupacion, inicio, fin)
        VALUES (%s, %s, %s, %s, %s, %s, %s)
    """

    valores = (
        data["categoria"],
        data.get("motivo"),
        data.get("nombre"),
        data.get("seccion"),
        data.get("ocupacion"),
        data["inicio"],
        data["fin"]
    )

    cursor.execute(sql, valores)
    conn.commit()

    nuevo_id = cursor.lastrowid

    cursor.close()
    conn.close()

    return jsonify({"mensaje": "Cita creada", "id": nuevo_id}), 201

@citas_bp.route("/citas/<int:id>", methods=["PUT"])
def actualizar_cita(id):
    data = request.json

    conn = get_db_connection()
    cursor = conn.cursor()

    sql = """
        UPDATE citas
        SET categoria = %s, motivo = %s, nombre = %s, seccion = %s, ocupacion = %s, inicio = %s, fin = %s
        WHERE id = %s
    """

    valores = (
        data["categoria"],
        data.get("motivo"),
        data.get("nombre"),
        data.get("seccion"),
        data.get("ocupacion"),
        data["inicio"],
        data["fin"],
        id
    )

    cursor.execute(sql, valores)
    conn.commit()

    cursor.close()
    conn.close()

    return jsonify({"mensaje": "Cita actualizada"}), 200

@citas_bp.route("/citas/<int:id>", methods=["DELETE"])
def eliminar_cita(id):
    conn = get_db_connection()
    cursor = conn.cursor()

    cursor.execute("DELETE FROM citas WHERE id = %s", (id,))
    conn.commit()

    cursor.close()
    conn.close()

    return jsonify({"mensaje": "Cita eliminada"}), 200
