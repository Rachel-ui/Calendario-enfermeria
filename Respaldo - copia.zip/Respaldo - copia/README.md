# Calendario de Citas Médicas

Una aplicación web completa para gestionar citas médicas con un calendario interactivo usando Event-Calendar.

## 🚀 Características

- **Calendario Interactivo**: Vista mensual con soporte para español
- **CRUD Completo**: Crear, leer, actualizar y eliminar citas
- **Arrastrar y Soltar**: Mover citas en el calendario
- **Redimensionar**: Cambiar duración de citas
- **API REST**: Backend Flask con endpoints RESTful
- **Base de Datos**: MySQL para almacenamiento persistente

## 📁 Estructura del Proyecto

```
/
├── app.py                 # Aplicación principal Flask
├── config.py             # Configuración de base de datos
├── db.py                 # Conexión a base de datos
├── schema.sql            # Esquema de base de datos
├── routes/
│   └── citas.py          # Endpoints de la API
├── index.html            # Página principal
├── calendar.js           # Lógica del calendario
├── eventos.js            # Carga de eventos desde API
├── global.css            # Estilos CSS
└── event-calendar.min.js # Librería Event-Calendar
```

## 🛠️ Instalación

### 1. Base de Datos

```sql
-- Ejecutar schema.sql en MySQL
mysql -u root -p < schema.sql
```

### 2. Dependencias Python

```bash
pip install flask flask-cors pymysql
```

### 3. Ejecutar la Aplicación

```bash
python app.py
```

La aplicación estará disponible en `http://127.0.0.1:5000`

## 📡 API Endpoints

### GET /api/citas
Obtener todas las citas formateadas para Event-Calendar.

**Respuesta:**
```json
[
  {
    "id": 1,
    "title": "Consulta: Juan Pérez",
    "start": "2024-01-15T09:00:00",
    "end": "2024-01-15T10:00:00",
    "extendedProps": {
      "categoria": "consulta",
      "motivo": "Chequeo general",
      "nombre": "Juan Pérez",
      "seccion": "Medicina General",
      "ocupacion": "Paciente"
    }
  }
]
```

### POST /api/citas
Crear una nueva cita.

**Cuerpo:**
```json
{
  "categoria": "consulta",
  "motivo": "Chequeo general",
  "nombre": "Juan Pérez",
  "inicio": "2024-01-15T09:00:00",
  "fin": "2024-01-15T10:00:00"
}
```

### PUT /api/citas/{id}
Actualizar una cita existente.

### DELETE /api/citas/{id}
Eliminar una cita.

## 🎯 Uso del Calendario

### Crear Cita
- Haz clic en cualquier día del calendario
- Completa el formulario y guarda

### Ver Detalles
- Haz clic en cualquier cita existente
- Verás los detalles completos

### Editar Cita
- Haz clic en una cita
- Presiona "Editar" en el modal de detalles
- Modifica los campos y guarda

### Eliminar Cita
- Haz clic en una cita
- Presiona "Eliminar" en el modal de detalles
- Confirma la eliminación

### Arrastrar y Soltar
- Arrastra cualquier cita a una nueva fecha/hora
- Los cambios se guardan automáticamente

### Redimensionar
- Arrastra el borde inferior de una cita para cambiar su duración
- Los cambios se guardan automáticamente

## 🗃️ Base de Datos

### Tabla `citas`

| Campo       | Tipo         | Descripción |
|-------------|--------------|-------------|
| id          | INT          | ID único (auto-incremental) |
| categoria   | VARCHAR(50)  | Tipo de cita (consulta, examen, cirugia) |
| motivo      | VARCHAR(255) | Motivo de la cita |
| nombre      | VARCHAR(255) | Nombre del paciente |
| seccion     | VARCHAR(100) | Sección médica |
| ocupacion   | VARCHAR(100) | Ocupación/Sector |
| inicio      | DATETIME     | Fecha y hora de inicio |
| fin         | DATETIME     | Fecha y hora de fin |
| created_at  | TIMESTAMP    | Fecha de creación |
| updated_at  | TIMESTAMP    | Fecha de actualización |

## 🎨 Personalización

### Estilos CSS
Los estilos se pueden modificar en `global.css` para adaptar la apariencia.

### Configuración
- Base de datos: `config.py`
- Puerto del servidor: `app.py` (línea 15)

## 🔧 Desarrollo

### Agregar Nuevos Campos
1. Actualizar `schema.sql`
2. Modificar `routes/citas.py`
3. Actualizar `calendar.js` y `index.html` si es necesario

### Nuevos Endpoints
Agregar nuevas rutas en `routes/citas.py` siguiendo el patrón existente.

## 📝 Notas

- La aplicación usa CORS para permitir peticiones desde el frontend
- Los eventos se cargan automáticamente al iniciar
- Los cambios en el calendario se sincronizan en tiempo real con la base de datos
- El calendario soporta vista mensual con navegación

## 🤝 Contribución

1. Fork el proyecto
2. Crea una rama para tu feature (`git checkout -b feature/nueva-funcionalidad`)
3. Commit tus cambios (`git commit -am 'Agrega nueva funcionalidad'`)
4. Push a la rama (`git push origin feature/nueva-funcionalidad`)
5. Abre un Pull Request
