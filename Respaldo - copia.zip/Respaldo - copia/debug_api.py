import requests

response = requests.get('http://127.0.0.1:5000/api/citas')
if response.status_code == 200:
    citas = response.json()
    print(f"Total citas: {len(citas)}")
    for i, cita in enumerate(citas):
        print(f"{i+1}: {cita['categoria']} - {cita.get('inicio')} - {cita.get('fin')}")
else:
    print("Error:", response.status_code)
