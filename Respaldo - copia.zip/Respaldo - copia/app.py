
from flask import Flask, send_from_directory
from flask_cors import CORS
from routes.citas import citas_bp

def create_app():
    app = Flask(__name__)
    CORS(app)  # Habilitar CORS

    # Registrar Blueprints
    app.register_blueprint(citas_bp, url_prefix="/api")

    @app.route("/")
    def home():
        return send_from_directory(".", "index.html")

    @app.route("/<path:path>")
    def static_files(path):
        return send_from_directory(".", path)

    return app

if __name__ == "__main__":
    app = create_app()
    app.run(debug=True, port=5000)
