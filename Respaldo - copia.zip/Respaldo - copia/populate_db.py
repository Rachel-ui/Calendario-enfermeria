import json
from db import get_db_connection

def populate_db():
    # Cargar datos de citas.json
    with open('citas.json', 'r', encoding='utf-8') as f:
        citas = json.load(f)

    conn = get_db_connection()
    cursor = conn.cursor()

    for cita in citas:
        sql = """
            INSERT INTO citas
            (categoria, motivo, nombre, seccion, ocupacion, inicio, fin)
            VALUES (%s, %s, %s, %s, %s, %s, %s)
        """
        valores = (
            cita['categoria'],
            cita.get('motivo'),
            cita.get('nombre'),
            cita.get('seccion'),
            cita.get('ocupacion'),
            cita['start'],  # Usar 'start' en lugar de 'inicio'
            cita.get('end')  # Usar 'end' en lugar de 'fin'
        )
        cursor.execute(sql, valores)

    conn.commit()
    cursor.close()
    conn.close()
    print("Datos insertados en la base de datos.")

if __name__ == "__main__":
    populate_db()
