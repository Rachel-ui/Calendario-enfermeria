document.addEventListener("DOMContentLoaded", async () => {
    console.log("📅 Inicializando Event-Calendar...");

    const calendarEl = document.getElementById("ec");
    if (!calendarEl) {
        console.error("❌ No existe el elemento #ec");
        return;
    }

    // ============================
    // 1️⃣ Cargar eventos desde API
    // ============================
    let eventos = [];
    try {
        eventos = await cargarEventos();
        console.log("📥 Eventos cargados:", eventos);
    } catch (e) {
        console.error("❌ Error cargando eventos", e);
    }

    // ============================
    // 2️⃣ Crear calendario
    // ⚠ IMPORTANTE: usar FullCalendar constructor
    // ============================
    const ec = new FullCalendar.Calendar(calendarEl, {
        initialView: "dayGridMonth",
        locale: "es",
        firstDay: 1,
        events: eventos,
        editable: true, // Permitir arrastrar y redimensionar eventos

        eventClick: (info) => {
            console.log("🟦 Evento clickeado:", info.event);
            mostrarDetalles(info.event);
        },

        dateClick: (info) => {
            console.log("🟩 Día clickeado:", info.dateStr);
            abrirModalCrear(info.dateStr);
        },

        eventDrop: async (info) => {
            console.log("📅 Evento movido:", info.event);
            await actualizarCita(info.event);
        },

        eventResize: async (info) => {
            console.log("📏 Evento redimensionado:", info.event);
            await actualizarCita(info.event);
        }
    });

    ec.render();

    console.log("✅ Event-Calendar inicializado correctamente");

    // ======================================================
    // 🟦 FUNCIÓN: MOSTRAR MODAL DE DETALLES
    // ======================================================
    let eventoActual = null;

    function mostrarDetalles(evento) {
        eventoActual = evento;
        const props = evento.extendedProps;

        document.getElementById("modalVerTitulo").innerText = evento.title;
        document.getElementById("modalVerFecha").innerText = formatearFecha(evento.start);
        document.getElementById("modalVerHora").innerText =
            formatearHora(evento.start) + " - " + formatearHora(evento.end);

        document.getElementById("modalVerNombre").innerText = props.nombre || "—";
        document.getElementById("modalVerMotivo").innerText = props.motivo || "—";
        document.getElementById("modalVerCategoria").innerText = props.categoria || "—";
        document.getElementById("modalVerSeccion").innerText = props.seccion || "—";
        document.getElementById("modalVerOcupacion").innerText = props.ocupacion || "—";

        const modal = document.getElementById("modalVer");
        const modalContent = modal.querySelector(".modal-content");
        modal.style.display = "block";
        modal.style.zIndex = "2000";
        modalContent.style.transform = "scale(1) translateY(0)";
        modalContent.style.opacity = "1";
        modalContent.style.zIndex = "2001";
    }

    // ======================================================
    // 🟩 MODAL CREAR EVENTO
    // ======================================================
    function abrirModalCrear(fecha) {
        document.getElementById("fechaInicio").value = fecha;
        document.getElementById("categoria").value = "";
        document.getElementById("nombre").value = "";
        document.getElementById("motivo").value = "";
        document.getElementById("seccion").value = "";
        document.getElementById("ocupacion").value = "";
        document.getElementById("horaInicio").value = "";
        document.getElementById("horaFin").value = "";
        delete document.getElementById("formCrear").dataset.editId;
        document.querySelector("#formCrear button[type='submit']").textContent = "Crear Cita";
        const modal = document.getElementById("modalCrear");
        const modalContent = modal.querySelector(".modal-content");
        modal.style.display = "block";
        modal.style.zIndex = "2000";
        modalContent.style.transform = "scale(1) translateY(0)";
        modalContent.style.opacity = "1";
        modalContent.style.zIndex = "2001";
    }

    document.getElementById("cerrarModalCrear").onclick = function () {
        document.getElementById("modalCrear").style.display = "none";
    };

    document.getElementById("cancelarCrear").onclick = function () {
        document.getElementById("modalCrear").style.display = "none";
    };

    document.getElementById("cerrarModalVer").onclick = function () {
        document.getElementById("modalVer").style.display = "none";
    };

    // ======================================================
    // ✏️ EDITAR CITA
    // ======================================================
    document.getElementById("btnEditarCita").onclick = function () {
        if (eventoActual) {
            const props = eventoActual.extendedProps;
            document.getElementById("categoria").value = props.categoria || "";
            document.getElementById("nombre").value = props.nombre || "";
            document.getElementById("motivo").value = props.motivo || "";
            document.getElementById("seccion").value = props.seccion || "";
            document.getElementById("ocupacion").value = props.ocupacion || "";
            document.getElementById("fechaInicio").value = eventoActual.start ? eventoActual.start.toISOString().split('T')[0] : "";
            document.getElementById("horaInicio").value = eventoActual.start ? eventoActual.start.toTimeString().slice(0, 5) : "";
            document.getElementById("horaFin").value = eventoActual.end ? eventoActual.end.toTimeString().slice(0, 5) : "";
            const form = document.getElementById("formCrear");
            form.dataset.editId = eventoActual.id;
            document.querySelector("#formCrear button[type='submit']").textContent = "Guardar Cita";
            document.getElementById("modalVer").style.display = "none";
            const modal = document.getElementById("modalCrear");
            const modalContent = modal.querySelector(".modal-content");
            modal.style.display = "block";
            modal.style.zIndex = "2000";
            modalContent.style.transform = "scale(1) translateY(0)";
            modalContent.style.opacity = "1";
            modalContent.style.zIndex = "2001";
        }
    };

    // ======================================================
    // 🗑️ ELIMINAR CITA
    // ======================================================
    document.getElementById("btnEliminarCita").onclick = function () {
        if (eventoActual) {
            eliminarCita(eventoActual.id);
        }
    };

    // ======================================================
    // 🗑️ FUNCIÓN ELIMINAR CITA
    // ======================================================
    async function eliminarCita(id) {
        const respuesta = await fetch(`http://127.0.0.1:5000/api/citas/${id}`, {
            method: "DELETE"
        });

        if (respuesta.ok) {
            location.reload();
        } else {
            console.error("Error al eliminar la cita");
        }
    }

    // ======================================================
    // 🟧 FORMULARIO CREAR/EDITAR EVENTO
    // ======================================================
    document.getElementById("formCrear").addEventListener("submit", async function (e) {
        e.preventDefault();

        const categoria = document.getElementById("categoria").value;
        const nombre = document.getElementById("nombre").value;
        const motivo = document.getElementById("motivo").value;
        const seccion = document.getElementById("seccion").value;
        const ocupacion = document.getElementById("ocupacion").value;
        const fecha = document.getElementById("fechaInicio").value;
        const horaInicio = document.getElementById("horaInicio").value;
        const horaFin = document.getElementById("horaFin").value;

        const inicio = `${fecha}T${horaInicio}:00`;
        const fin = `${fecha}T${horaFin}:00`;

        const editId = this.dataset.editId;
        const method = editId ? "PUT" : "POST";
        const url = editId ? `http://127.0.0.1:5000/api/citas/${editId}` : "http://127.0.0.1:5000/api/citas";

        const data = {
            categoria,
            motivo,
            nombre,
            seccion,
            ocupacion,
            inicio,
            fin
        };

        const respuesta = await fetch(url, {
            method: method,
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(data)
        });

        if (respuesta.ok) {
            location.reload();
        } else {
            console.error("Error al guardar la cita");
        }
    });

    // ======================================================
    // 🔄 ACTUALIZAR CITA (DRAG & DROP / RESIZE)
    // ======================================================
    async function actualizarCita(evento) {
        const respuesta = await fetch(`http://127.0.0.1:5000/api/citas/${evento.id}`, {
            method: "PUT",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
                categoria: evento.extendedProps.categoria,
                motivo: evento.extendedProps.motivo,
                nombre: evento.extendedProps.nombre,
                seccion: evento.extendedProps.seccion,
                ocupacion: evento.extendedProps.ocupacion,
                inicio: evento.start.toISOString(),
                fin: evento.end.toISOString()
            })
        });

        if (!respuesta.ok) {
            console.error("Error al actualizar la cita");
            location.reload(); // Recargar para revertir cambios
        }
    }

    // ======================================================
    // ⏱ FORMATOS
    // ======================================================
    function formatearFecha(fecha) {
        if (!fecha) return "—";
        return fecha.toLocaleDateString("es-CR", {
            year: "numeric",
            month: "long",
            day: "numeric"
        });
    }

    function formatearHora(fecha) {
        if (!fecha) return "—";
        return fecha.toLocaleTimeString("es-CR", {
            hour: "2-digit",
            minute: "2-digit"
        });
    }
});
