// =========================
// COLORES POR CATEGORÍA
// =========================
const categorias = {
  Estudiantes: "#1e4fffff",
  Colaboradores: "#2da712ff",
  Escuela: "#fb00ffff",
  Etai: "#c5c032ff"
};

// -------------------------------------------------------
// CREADORES DE EVENTOS → TRANSFORMAN API → FullCalendar
// -------------------------------------------------------

function crearEventoEstudiante(id, start, end, motivo, nombre, seccion) {
  return {
    id,
    title: "Atención Estudiantil",
    start: new Date(start),
    end: end ? new Date(end) : null,
    backgroundColor: categorias.Estudiantes,
    borderColor: categorias.Estudiantes,
    categoria: "Estudiantes",

    // Datos adicionales
    extendedProps: {
      motivo,
      nombre,
      seccion,
      categoria: "Estudiantes"
    }
  };
}

function crearEventoEtai(id, start, end, motivo, nombre, ocupacion) {
  return {
    id,
    title: "Cita ETAI",
    start: new Date(start),
    end: end ? new Date(end) : null,
    backgroundColor: categorias.Etai,
    borderColor: categorias.Etai,
    categoria: "Etai",

    extendedProps: {
      motivo,
      nombre,
      ocupacion,
      categoria: "Etai"
    }
  };
}

function crearEventoEscuela(id, start, end, motivo, nombre, seccion, ocupacion) {
  return {
    id,
    title: "Cita Escolar",
    start: new Date(start),
    end: end ? new Date(end) : null,
    backgroundColor: categorias.Escuela,
    borderColor: categorias.Escuela,
    categoria: "Escuela",

    extendedProps: {
      motivo,
      nombre,
      seccion,
      ocupacion,
      categoria: "Escuela"
    }
  };
}

function crearEventoColaborador(id, start, end, motivo, nombre, seccion, ocupacion) {
  return {
    id,
    title: "Atención Colaborador",
    start: new Date(start),
    end: end ? new Date(end) : null,
    backgroundColor: categorias.Colaboradores,
    borderColor: categorias.Colaboradores,
    categoria: "Colaboradores",

    extendedProps: {
      motivo,
      nombre,
      seccion,
      ocupacion,
      categoria: "Colaboradores"
    }
  };
}

// =============================================
// FUNCIÓN PRINCIPAL PARA CARGAR EVENTOS DE API
// =============================================
async function cargarEventos() {
  try {
    const response = await fetch("http://127.0.0.1:5000/api/citas");
    const data = await response.json();

    // Convertir API → formato de calendario
    return data.map(item => {
      const { id, start, end, extendedProps } = item;
      const { categoria, motivo, nombre, ocupacion, seccion } = extendedProps;

      switch (categoria) {
        case "Estudiantes":
          return crearEventoEstudiante(id, start, end, motivo, nombre, seccion);

        case "Etai":
          return crearEventoEtai(id, start, end, motivo, nombre, ocupacion);

        case "Escuela":
          return crearEventoEscuela(id, start, end, motivo, nombre, seccion, ocupacion);

        case "Colaboradores":
          return crearEventoColaborador(id, start, end, motivo, nombre);

        default:
          console.warn("Categoría desconocida:", categoria);
          // Crear evento genérico para categorías desconocidas
          return {
            id,
            title: `${categoria.charAt(0).toUpperCase() + categoria.slice(1)}: ${nombre}`,
            start: new Date(start),
            end: end ? new Date(end) : null,
            backgroundColor: "#3788d8",
            borderColor: "#3788d8",
            categoria: categoria,

            extendedProps: {
              motivo,
              nombre,
              ocupacion,
              seccion,
              categoria: categoria
            }
          };
      }
    }).filter(e => e !== null);

  } catch (error) {
    console.error("Error cargando eventos:", error);
    return [];
  }
}
