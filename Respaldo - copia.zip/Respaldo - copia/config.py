DB_CONFIG = {
    "host": "localhost",
    "user": "root",
    "password": "bd0E",
    "database": "clinica"
}
